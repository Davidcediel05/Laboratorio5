import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.signal import butter, find_peaks
import pywt
from scipy.interpolate import interp1d


# ========================
# 1. Parámetros del filtro
# ========================
frecuencia_muestreo = 1000  # Hz
corte_bajo = 0.5            # Hz
corte_alto = 45.0           # Hz
orden_filtro = 4

# ==============================
# 2. Cargar la señal modificada
# ==============================
datos = pd.read_csv("ecg_waveform.csv")
tiempo = datos["time_seconds"].values
voltaje = datos["voltage_mV"].values

# ============================
# 3. Diseñar filtro pasa banda
# ============================
def filtro_pasabanda_butter(bajo, alto, fs, orden):
    nyquist = 0.5 * fs
    bajo_norm = bajo / nyquist
    alto_norm = alto / nyquist
    b, a = butter(orden, [bajo_norm, alto_norm], btype='band')
    return b, a

coef_b, coef_a = filtro_pasabanda_butter(corte_bajo, corte_alto, frecuencia_muestreo, orden_filtro)

# =====================================================
# 4. Mostrar la ecuación en diferencias del filtro IIR
# =====================================================
print(f"\nEcuación en diferencias del filtro de orden {orden_filtro}:")
entrada = [f"{coef_b[i]:.6f}·x[n-{i}]" for i in range(len(coef_b))]
salida = [f"{coef_a[j]:.6f}·y[n-{j}]" for j in range(1, len(coef_a))]
print("y[n] = " + " + ".join(entrada) + (" - (" + " + ".join(salida) + ")" if salida else ""))

# ==========================================================
# 5. Aplicar el filtro manualmente (condiciones iniciales 0)
# ==========================================================
def aplicar_filtro(b, a, señal):
    salida = np.zeros_like(señal)
    for n in range(len(señal)):
        for i in range(len(b)):
            if n - i >= 0:
                salida[n] += b[i] * señal[n - i]
        for j in range(1, len(a)):
            if n - j >= 0:
                salida[n] -= a[j] * salida[n - j]
    return salida

voltaje_filtrado = aplicar_filtro(coef_b, coef_a, voltaje)

# =================================================
# 6. Graficar señal original y filtrada (10 segundos)
# =================================================
plt.figure(figsize=(12, 4))
plt.plot(tiempo[:10000], voltaje[:10000], label='Original', alpha=0.5)
plt.plot(tiempo[:10000], voltaje_filtrado[:10000], label='Filtrada', linewidth=2)
plt.title("Señal ECG modificada: Original vs Filtrada (primeros 10 s)")
plt.xlabel("Tiempo (s)")
plt.ylabel("Voltaje (mV)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# =================================================
# 7. Detección de picos R con umbral ajustable
# =================================================
umbral_altura = 0.3  # Ajustable según señal
distancia_minima = int(frecuencia_muestreo * 0.6)  # separación mínima entre picos
picos, _ = find_peaks(voltaje, height=umbral_altura, distance=distancia_minima)

print(f"\nSe detectaron {len(picos)} picos R en la señal.")

# Mostrar picos en primeros 10 segundos
plt.figure(figsize=(12, 4))
plt.plot(tiempo[:10000], voltaje[:10000], label='Señal original')
plt.plot(tiempo[picos[(picos < 10000)]], voltaje[picos[(picos < 10000)]], 'rx', label='Picos R')
plt.title("Picos R detectados (primeros 10 s)")
plt.xlabel("Tiempo (s)")
plt.ylabel("Voltaje (mV)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ===============================================
# 8. Calcular intervalos R-R y frecuencia cardíaca
# ===============================================
intervalos_rr = np.diff(tiempo[picos])
tiempos_rr = tiempo[picos][1:]
frecuencia_bpm = 60 / intervalos_rr

print("\n🫀 Primeros 10 intervalos R-R y su BPM:")
for i in range(min(10, len(intervalos_rr))):
    print(f"R-R {i+1}: {intervalos_rr[i]:.3f} s -> {frecuencia_bpm[i]:.1f} BPM")

# ===============================================
# 9. Parámetros de HRV en dominio del tiempo
# ===============================================
media_rr = np.mean(intervalos_rr)
sdnn = np.std(intervalos_rr)
media_rr_ms = media_rr * 1000
sdnn_ms = sdnn * 1000

print("\n📊 Parámetros de variabilidad de frecuencia cardíaca (HRV):")
print(f"Media de intervalos R-R: {media_rr_ms:.2f} ms")
print(f"Desviación estándar (SDNN): {sdnn_ms:.2f} ms")
# ===============================================
# 10. Espectrograma de HRV con Transformada Wavelet Continua
# ===============================================


# Interpolar los intervalos R-R para una señal uniforme (frecuencia: 4 Hz típica en HRV)
frecuencia_interpolacion = 4  # Hz
tiempo_interp = np.arange(tiempos_rr[0], tiempos_rr[-1], 1 / frecuencia_interpolacion)
interpolador = interp1d(tiempos_rr, intervalos_rr, kind='cubic')
rr_interp = interpolador(tiempo_interp)

# Escalas y wavelet
wavelet = 'cmor1.5-1.0'  # Morlet compleja ajustada
escala_min = 1
escala_max = 128
num_escalas = 100
escalas = np.linspace(escala_min, escala_max, num_escalas)

# CWT
coeficientes, frecuencias = pywt.cwt(rr_interp, scales=escalas, wavelet=wavelet, sampling_period=1/frecuencia_interpolacion)

# Mostrar espectrograma
plt.figure(figsize=(12, 6))
plt.imshow(np.abs(coeficientes), extent=[tiempo_interp[0], tiempo_interp[-1], frecuencias[-1], frecuencias[0]],
           cmap='jet', aspect='auto')
plt.colorbar(label='Amplitud')
plt.title("Espectrograma de HRV usando Wavelet Continua (Morlet)")
plt.ylabel("Frecuencia (Hz)")
plt.xlabel("Tiempo (s)")
plt.ylim(0, 0.5)  # HRV frecuencias típicas: 0–0.5 Hz
plt.tight_layout()
plt.show()