import pandas as pd
import numpy as np
from scipy.signal import find_peaks
import matplotlib.pyplot as plt

# Cargar la señal original
df = pd.read_csv("ecg_waveform.csv")  # Asegúrate de que esté en el mismo directorio
tiempo = df["time_seconds"].values
voltaje = df["voltage_mV"].values

# Detección de picos R para ajustar según ritmo
picos, _ = find_peaks(voltaje, height=0.4, distance=200)

# 1. Variabilidad respiratoria (baja frecuencia ~0.2 Hz)
variabilidad_rr = 0.03 * np.sin(2 * np.pi * 0.2 * tiempo)

# 2. Artefactos tipo movimiento (pulsos suaves)
artefactos = np.zeros_like(voltaje)
for _ in range(15):  # 15 artefactos
    idx = np.random.randint(0, len(voltaje) - 50)
    artefactos[idx:idx + 50] += np.random.uniform(-0.1, 0.1) * np.hanning(50)

# 3. Ruido EMG esporádico
ruido_emg = np.random.normal(0, 0.02, size=len(voltaje))
máscara_emg = np.random.choice([0, 1], size=len(voltaje), p=[0.98, 0.02])
ruido_emg *= máscara_emg

# Señal final más realista
voltaje_realista = voltaje + artefactos + ruido_emg

# Guardar la nueva señal
df_realista = pd.DataFrame({
    "time_seconds": tiempo,
    "voltage_mV": voltaje_realista
})
df_realista.to_csv("ecg_waveform_realista.csv", index=False)

# Visualizar comparación
plt.figure(figsize=(12, 4))
plt.plot(tiempo[:5000], voltaje[:5000], label="Original", alpha=0.5)
plt.plot(tiempo[:5000], voltaje_realista[:5000], label="Realista", linewidth=2)
plt.legend()
plt.title("Comparación de señal ECG original vs simulada realista")
plt.xlabel("Tiempo (s)")
plt.ylabel("Voltaje (mV)")
plt.grid(True)
plt.tight_layout()
plt.show()